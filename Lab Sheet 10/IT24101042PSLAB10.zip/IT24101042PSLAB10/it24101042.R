setwd("C:\\Users\\Kavisha Perera\\OneDrive\\Desktop\\IT24101042")

#ii
# Observed frequencies
observed <- c(120, 95, 85, 100)

prob <- c(0.25, 0.25, 0.25, 0.25)

chisq.test(x=observed, p=prob)
