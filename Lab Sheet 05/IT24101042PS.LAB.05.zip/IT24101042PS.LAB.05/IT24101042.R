setwd("C:\\Users\\Kavisha Perera\\OneDrive\\Desktop\\IT24101042PS.LAB.05")
# Read the dataset
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE, sep=",")
head(Delivery_Times)# Preview first few rows
# Define class boundaries
breaks <- seq(20, 70, length.out = 10)
# Plot histogram
hist(Delivery_Times$Delivery_Time,
     breaks = breaks,
     right = FALSE,  # left-closed, right-open intervals
     col = "lightblue",
     xlab = "Delivery Time (minutes)",
     ylab = "Frequency",
     main = "Histogram of Delivery Times")
# Compute cumulative frequency
cum_freq <- c(0, cumsum(table(cut(Delivery_Times$Delivery_Time, breaks = breaks, right = FALSE))))
# Plot the ogive
plot(breaks, cum_freq, type = "o",
     col = "blue",
     pch = 16,
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency",
     main = "Cumulative Frequency Polygon (Ogive)")
