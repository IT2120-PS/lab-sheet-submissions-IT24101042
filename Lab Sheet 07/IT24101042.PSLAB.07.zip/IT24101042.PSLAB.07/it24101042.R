setwd("C:\\Users\\Kavisha Perera\\OneDrive\\Desktop\\IT24101042.PSLAB.07")
# Q1: Uniform Distribution
# X ~ Uniform(0, 40)
a <- 0
b <- 40
p1 <- (25 - 10) / (b - a)
p1
# Q2: Exponential Distribution
lambda <- 1/3
p2 <- pexp(2, rate = lambda)
p2
# Q3: Normal Distribution
mu <- 100
sigma <- 15

# (i) P(X > 130)
p3_i <- 1 - pnorm(130, mean = mu, sd = sigma)
p3_i

# (ii) 95th percentile
p3_ii <- qnorm(0.95, mean = mu, sd = sigma)
p3_ii
