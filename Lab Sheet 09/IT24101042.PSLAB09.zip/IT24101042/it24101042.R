
## Question 01
## Part 1
x <- rnorm(25, mean = 45, sd = 2) # generate 25 random baking times
print(x)

## Part 2
# Hypothesis:
# H0: μ >= 46
# H1: μ < 46
# Significance level = 5%

# Perform one-sample t-test
t.test(x, mu = 46, alternative = "less")
