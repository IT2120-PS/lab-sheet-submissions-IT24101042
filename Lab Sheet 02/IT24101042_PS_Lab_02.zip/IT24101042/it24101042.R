
vector <- c(15)
result <- sum(vector %% 3 == 0)
print(result)

vector2 <-c(20,10,30,40)
maxindex <-1
for (i in 1:length(vector2)){
      if(vector2[i]>vector2[maxindex]){
        maxindex <-i
      }
}
maxindex
which.max(vector2)